﻿using System;

public class helperFunctions
{
	public helperFunctions()
	{
	}
}
